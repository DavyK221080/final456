import request from "supertest";
import app from "../index.js";

let token;

beforeAll(async () => {
  const response = await request(app).post("/auth/login").send({
    email: "johndoe@example.com",
    password: "password123",
  });
  token = response.body.token;
});

describe("Amenities API", () => {
  it("should return all amenities", async () => {
    const response = await request(app)
      .get("/amenities")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toBeInstanceOf(Array);
    expect(response.body.length).toBeGreaterThan(0);
  });

  it("should return amenity by ID", async () => {
    const response = await request(app)
      .get("/amenities/l4567890-12gh-ijkl-1234-56789abcdef0")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toHaveProperty(
      "id",
      "l4567890-12gh-ijkl-1234-56789abcdef0"
    );
  });

  it("should return 404 for non-existing amenity", async () => {
    const response = await request(app)
      .get("/amenities/non-existing-id")
      .set("Authorization", `Bearer ${token}`)
      .expect(404);

    expect(response.body).toHaveProperty("error", "Amenity not found");
  });
});
