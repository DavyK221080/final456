import request from "supertest";
import app from "../index";

describe("Bookings API", () => {
  let token;

  beforeAll(async () => {
    const response = await request(app).post("/auth/login").send({
      email: "johndoe@example.com",
      password: "password123",
    });
    token = response.body.token;
  });

  it("should return all bookings for a given user", async () => {
    const response = await request(app)
      .get("/bookings")
      .set("Authorization", `Bearer ${token}`)
      .expect(200);

    expect(response.body).toBeInstanceOf(Array);
    expect(response.body.length).toBeGreaterThan(0);

    const booking = response.body.find(
      (booking) => booking.userId === "a1234567-89ab-cdef-0123-456789abcdef"
    );
    expect(booking).toBeDefined();
    expect(booking.userId).toBe("a1234567-89ab-cdef-0123-456789abcdef");
    expect(booking.propertyId).toBe("g9012345-67ef-0123-4567-89abcdef0123");
    expect(booking.checkinDate).toBe("2023-03-10T18:00:00.000Z");
    expect(booking.checkoutDate).toBe("2023-03-15T10:00:00.000Z");
    expect(booking.numberOfGuests).toBe(2);
    expect(booking.totalPrice).toBe(150.25);
    expect(booking.bookingStatus).toBe("confirmed");
  });
});
