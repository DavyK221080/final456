import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const getAllProperties = async (req, res) => {
  try {
    const properties = await prisma.property.findMany();
    res.json(properties);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching properties" });
  }
};

export const createProperty = async (req, res) => {
  try {
    const {
      title,
      description,
      location,
      pricePerNight,
      bedroomCount,
      bathRoomCount,
      maxGuestCount,
      hostId,
      rating,
    } = req.body;
    const newProperty = await prisma.property.create({
      data: {
        title,
        description,
        location,
        pricePerNight,
        bedroomCount,
        bathRoomCount,
        maxGuestCount,
        hostId,
        rating,
      },
    });
    res.status(201).json(newProperty);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while creating property" });
  }
};

export const getPropertyById = async (req, res) => {
  try {
    const { id } = req.params;
    const property = await prisma.property.findUnique({ where: { id } });
    if (property) {
      res.json(property);
    } else {
      res.status(404).json({ error: "Property not found" });
    }
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching property" });
  }
};

export const updateProperty = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      location,
      pricePerNight,
      bedroomCount,
      bathRoomCount,
      maxGuestCount,
      hostId,
      rating,
    } = req.body;
    const updatedProperty = await prisma.property.update({
      where: { id },
      data: {
        title,
        description,
        location,
        pricePerNight,
        bedroomCount,
        bathRoomCount,
        maxGuestCount,
        hostId,
        rating,
      },
    });
    res.json(updatedProperty);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while updating property" });
  }
};

export const deleteProperty = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.property.delete({ where: { id } });
    res.status(204).end();
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while deleting property" });
  }
};

export const searchProperties = async (req, res) => {
  try {
    const { location, pricePerNight, amenities } = req.query;
    const filters = {};
    if (location) filters.location = { contains: location };
    if (pricePerNight)
      filters.pricePerNight = { lte: parseFloat(pricePerNight) };
    if (amenities)
      filters.amenities = { some: { name: { contains: amenities } } };

    const properties = await prisma.property.findMany({ where: filters });
    if (properties.length === 0) {
      res.status(404).json({ error: "Property not found" });
    } else {
      res.json(properties);
    }
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while searching properties" });
  }
};
