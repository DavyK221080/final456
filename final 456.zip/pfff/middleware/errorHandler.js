import * as Sentry from "@sentry/node";

const errorHandler = (err, req, res, next) => {
  Sentry.captureException(err);
  console.error(err.stack);
  res.status(500).json({
    error: "An error occurred on the server, please double-check your request!",
  });
};

export default errorHandler;
