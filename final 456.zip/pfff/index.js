import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import users from "./routes/users.js";
import hosts from "./routes/hosts.js";
import properties from "./routes/properties.js";
import amenities from "./routes/amenities.js";
import bookings from "./routes/bookings.js";
import reviews from "./routes/reviews.js";
import authRouter from "./routes/auth.js";
import * as Sentry from "@sentry/node";
import * as Tracing from "@sentry/tracing";
import loggingMiddleware from "./middleware/loggingMiddleware.js";
import errorHandler from "./middleware/errorHandler.js";
import { authenticate } from "./middleware/authMiddleware.js";
import dotenv from "dotenv";

dotenv.config();

const app = express();

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  integrations: [
    new Sentry.Integrations.Http({ tracing: true }),
    new Tracing.Integrations.Express({ app }),
  ],
  tracesSampleRate: 1.0,
});

app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.tracingHandler());

app.use(cors());
app.use(bodyParser.json());
app.use(loggingMiddleware);

app.use("/auth", authRouter);
app.use("/users", authenticate, users);
app.use("/hosts", authenticate, hosts);
app.use("/properties", authenticate, properties);
app.use("/amenities", authenticate, amenities);
app.use("/bookings", authenticate, bookings);
app.use("/reviews", authenticate, reviews);

app.use(Sentry.Handlers.errorHandler());
app.use(errorHandler);

if (process.env.NODE_ENV !== "test") {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
  });
}

export default app;
