import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllAmenities,
  createAmenity,
  getAmenityById,
  updateAmenity,
  deleteAmenity,
  searchAmenities,
} from "../services/amenityService.js";

const router = express.Router();

router.get("/", authenticate, getAllAmenities);
router.post("/", authenticate, createAmenity);
router.get("/search", authenticate, searchAmenities);
router.get("/:id", authenticate, getAmenityById);
router.put("/:id", authenticate, updateAmenity);
router.delete("/:id", authenticate, deleteAmenity);

export default router;
