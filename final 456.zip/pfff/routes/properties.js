import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllProperties,
  createProperty,
  getPropertyById,
  updateProperty,
  deleteProperty,
  searchProperties,
} from "../services/propertyService.js";

const router = express.Router();

router.get("/", authenticate, getAllProperties);
router.post("/", authenticate, createProperty);
router.get("/search", authenticate, searchProperties);
router.get("/:id", authenticate, getPropertyById);
router.put("/:id", authenticate, updateProperty);
router.delete("/:id", authenticate, deleteProperty);

export default router;
