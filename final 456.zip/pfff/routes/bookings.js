import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllBookings,
  createBooking,
  getBookingById,
  updateBooking,
  deleteBooking,
  searchBookings,
} from "../services/bookingService.js";

const router = express.Router();

router.get("/", authenticate, getAllBookings);
router.post("/", authenticate, createBooking);
router.get("/search", authenticate, searchBookings);
router.get("/:id", authenticate, getBookingById);
router.put("/:id", authenticate, updateBooking);
router.delete("/:id", authenticate, deleteBooking);

export default router;
