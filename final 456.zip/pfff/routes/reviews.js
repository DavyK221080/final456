import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllReviews,
  createReview,
  getReviewById,
  updateReview,
  deleteReview,
  searchReviews,
} from "../services/reviewService.js";

const router = express.Router();

router.get("/", authenticate, getAllReviews);
router.post("/", authenticate, createReview);
router.get("/search", authenticate, searchReviews);
router.get("/:id", authenticate, getReviewById);
router.put("/:id", authenticate, updateReview);
router.delete("/:id", authenticate, deleteReview);

export default router;
